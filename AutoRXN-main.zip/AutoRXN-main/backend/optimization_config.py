
from typing import List, Optional, Any, Callable, Dict
from pydantic import BaseModel, Field, field_validator, computed_field
from metadata import MetaData, DataType
from optimization_problem import OptimizationProblem
from dataclasses import asdict
import streamlit as st
import pandas as pd
from datetime import datetime
# Make sure to import your MetaData class
# from your_module import MetaData


class OptimizationConfig(BaseModel):
    """
    Main configuration class for optimization problems.
    Handles serialization/deserialization between Streamlit, FastAPI, and optimization tools.
    """
    # Problem definition
    problem_name: str = Field(..., description="Name of the optimization problem")
    description: str = Field(default="", description="Description of the optimization problem")
    
    # Variables and targets
    parameters: List[MetaData] = Field(default_factory=list, description="Input parameters for optimization")
    targets: List[MetaData] = Field(default_factory=list, description="Target variables to optimize")
    
    # Optimization settings
    maximize: bool = Field(default=True, description="Whether to maximize or minimize")
    
    # Algorithm settings
    algorithm: str = Field(default="genetic", description="Optimization algorithm to use")
    algorithm_params: Dict[str, Any] = Field(default_factory=dict, description="Algorithm-specific parameters")
        
    # Results and history
    best_solution: Optional[Dict[str, Any]] = Field(default=None, description="Best solution found")
    optimization_history: List[Dict[str, Any]] = Field(default_factory=list, description="History of optimization runs")
    
    @field_validator('parameters', 'targets')
    def validate_metadata_lists(cls, v):
        """Ensure all items in lists are MetaData objects"""
        if not all(isinstance(item, MetaData) for item in v):
            raise ValueError("All items must be MetaData objects")
        return v
    
    def to_optimization_problem(self) -> OptimizationProblem:
        """Convert to OptimizationProblem for the optimization tool"""
        return OptimizationProblem(
            param_metadatas=self.parameters,
            targets=self.targets,
            maximize=self.maximize,
            n_outputs=len(self.targets)
        )
    
    @classmethod
    def from_optimization_problem(cls, problem: OptimizationProblem, 
                                 problem_name: str = "Optimization Problem") -> 'OptimizationConfig':
        """Create config from OptimizationProblem"""
        return cls(
            problem_name=problem_name,
            parameters=problem.param_metadatas,
            targets=problem.targets,
            maximize=problem.maximize
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return self.model_dump()
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'OptimizationConfig':
        """Create from dictionary"""
        return cls(**data)
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return self.model_dump_json()
    
    @classmethod
    def from_json(cls, json_str: str) -> 'OptimizationConfig':
        """Create from JSON string"""
        return cls.model_validate(json_str)

class StreamlitConfigManager:
    """
    Manages configuration state in Streamlit sessions
    """
    
    @staticmethod
    def initialize_session_state():
        """Initialize Streamlit session state with default config"""
        if 'optimization_config' not in st.session_state:
            st.session_state.optimization_config = OptimizationConfig(
                problem_name="New Problem"
            )
    
    @staticmethod
    def save_config_to_session(config: OptimizationConfig):
        """Save configuration to Streamlit session state"""
        st.session_state.optimization_config = config
    
    @staticmethod
    def get_config_from_session() -> OptimizationConfig:
        """Get configuration from Streamlit session state"""
        return st.session_state.get('optimization_config', 
                                   OptimizationConfig(problem_name="Default"))
    
    @staticmethod
    def update_parameter(param_name: str, **kwargs):
        """Update a specific parameter in the session config"""
        config = StreamlitConfigManager.get_config_from_session()
        for param in config.parameters:
            if param.parameter_name == param_name:
                for key, value in kwargs.items():
                    if hasattr(param, key):
                        setattr(param, key, value)
        StreamlitConfigManager.save_config_to_session(config)
    
    @staticmethod
    def add_parameter(metadata: MetaData):
        """Add a new parameter to the session config"""
        config = StreamlitConfigManager.get_config_from_session()
        config.parameters.append(metadata)
        StreamlitConfigManager.save_config_to_session(config)
    
    @staticmethod
    def remove_parameter(param_name: str):
        """Remove a parameter from the session config"""
        config = StreamlitConfigManager.get_config_from_session()
        config.parameters = [p for p in config.parameters if p.parameter_name != param_name]
        StreamlitConfigManager.save_config_to_session(config)


class FastAPIConfigHandler:
    """
    Handles configuration serialization/deserialization for FastAPI endpoints
    """
    
    @staticmethod
    def prepare_for_api(config: OptimizationConfig) -> Dict[str, Any]:
        """Prepare configuration for API transmission"""
        # Convert to dict and handle any non-serializable objects
        config_dict = config.to_dict()
        
        # Remove any callable functions or other non-serializable items
        if 'evaluation_f' in config_dict:
            del config_dict['evaluation_f']
            
        return config_dict
    
    @staticmethod
    def restore_from_api(config_dict: Dict[str, Any]) -> OptimizationConfig:
        """Restore configuration from API response"""
        return OptimizationConfig.from_dict(config_dict)
    
    @staticmethod
    def create_api_request_body(config: OptimizationConfig, 
                              additional_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create request body for API calls"""
        body = {
            "config": FastAPIConfigHandler.prepare_for_api(config),
            "timestamp": str(pd.Timestamp.now()) if 'pd' in globals() else str(datetime.now())
        }
        
        if additional_params:
            body.update(additional_params)
            
        return body


class ConfigValidator:
    """
    Validates configuration consistency and completeness
    """
    
    @staticmethod
    def validate_config(config: OptimizationConfig) -> List[str]:
        """Validate configuration and return list of issues"""
        issues = []
        
        # Check basic requirements
        if not config.problem_name.strip():
            issues.append("Problem name is required")
        
        if not config.parameters:
            issues.append("At least one parameter is required")
        
        if not config.targets:
            issues.append("At least one target is required")
        
        # Validate parameters
        for i, param in enumerate(config.parameters):
            param_issues = ConfigValidator._validate_metadata(param, f"Parameter {i+1}")
            issues.extend(param_issues)
        
        # Validate targets
        for i, target in enumerate(config.targets):
            target_issues = ConfigValidator._validate_metadata(target, f"Target {i+1}")
            issues.extend(target_issues)
        
        # Check for duplicate names
        all_names = [p.parameter_name for p in config.parameters] + [t.parameter_name for t in config.targets]
        if len(all_names) != len(set(all_names)):
            issues.append("Duplicate parameter/target names found")
        
        return issues
    
    @staticmethod
    def _validate_metadata(metadata: MetaData, context: str) -> List[str]:
        """Validate individual MetaData object"""
        issues = []
        
        if not metadata.parameter_name.strip():
            issues.append(f"{context}: Parameter name is required")
        
        if metadata.data_type == DataType.categorical:
            if not metadata.choices:
                issues.append(f"{context}: Categorical variables must have choices")
            elif metadata.n_cat_choices != len(metadata.choices):
                issues.append(f"{context}: n_cat_choices doesn't match choices length")
        
        elif metadata.data_type in [DataType.continuous, DataType.ordinal]:
            if metadata.search_space[0] >= metadata.search_space[1]:
                issues.append(f"{context}: Invalid search space range")
        
        return issues


# Utility functions for easy integration
def create_config_from_streamlit_form() -> OptimizationConfig:
    """
    Helper function to create configuration from Streamlit form inputs
    Usage in Streamlit:
    
    with st.form("optimization_config"):
        config = create_config_from_streamlit_form()
        if st.form_submit_button("Save Configuration"):
            StreamlitConfigManager.save_config_to_session(config)
    """
    problem_name = st.text_input("Problem Name", value="New Optimization Problem")
    description = st.text_area("Description", value="")
    maximize = st.checkbox("Maximize objective", value=True)
    
    config = OptimizationConfig(
        problem_name=problem_name,
        description=description,
        maximize=maximize
    )
    
    return config


def sync_config_with_fastapi(config: OptimizationConfig, api_endpoint: str) -> OptimizationConfig:
    """
    Synchronize configuration with FastAPI backend
    
    Args:
        config: Current configuration
        api_endpoint: FastAPI endpoint URL
    
    Returns:
        Updated configuration from API
    """
    import requests
    
    try:
        # Prepare request
        request_body = FastAPIConfigHandler.create_api_request_body(config)
        
        # Send to API
        response = requests.post(f"{api_endpoint}/sync_config", json=request_body)
        response.raise_for_status()
        
        # Parse response
        updated_config_dict = response.json()["config"]
        return FastAPIConfigHandler.restore_from_api(updated_config_dict)
        
    except Exception as e:
        st.error(f"Failed to sync with API: {str(e)}")
        return config
