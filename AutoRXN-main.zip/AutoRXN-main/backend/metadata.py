from pydantic import BaseModel, Field, field_validator
from typing import List, Tuple, Union
from enum import Enum

class DataType(str, Enum):
    categorical = "categorical"
    continuous = "continuous"
    ordinal = "ordinal"
    target = "target"

class MetaData(BaseModel):
    parameter_name: str = Field(default="param", description="Name of the parameter")
    unit: str = Field(default="", description="Unit of measurement")
    data_type: DataType = Field(default=DataType.continuous, description="Type of data: target, categorical, continuous, or ordinal")    
    search_space: Tuple[float, float] = Field(default=(0, 1), description="Min and max values for search space")
    choices: List[str] = Field(default_factory=list, description="List of string choices for categorical data")
    n_cat_choices: int = Field(default=0, description="Number of categorical choices")
    
    @field_validator('search_space')
    def validate_search_space(cls, v):
        if len(v) != 2:
            raise ValueError('search_space must be a tuple of exactly 2 values')
        if v[0] >= v[1]:
            raise ValueError('search_space minimum must be less than maximum')
        return v
    
    @field_validator('n_cat_choices')
    def validate_n_cat_choices(cls, v):
        if v < 0:
            raise ValueError('n_cat_choices must be non-negative')
        return v
    
    def transform_function(self, X: Union[float, int]) -> float:
        """Transform input X to normalized space [0,1]"""
        diff = self.search_space[1] - self.search_space[0]
        X_t = (X - self.search_space[0]) / diff
        return X_t
    
    def untransform_function(self, X: Union[float, int]) -> float:
        """Transform normalized input X back to original space"""
        diff = self.search_space[1] - self.search_space[0]
        X_un = X * diff + self.search_space[0]
        return X_un