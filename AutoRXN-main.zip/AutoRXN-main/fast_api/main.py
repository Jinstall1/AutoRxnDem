from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append('/home/kinnunes/WebBO/backend')
from backend.test_BO import *
from backend.optimization_config import OptimizationConfig, FastAPIConfigHandler
from datetime import datetime

app = FastAPI(title="My App API", version="1.0.0")

# Enable CORS for Streamlit
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501"],  # Streamlit default port
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response
class Item(BaseModel):
    id: Optional[int] = None
    name: str
    description: Optional[str] = None
    created_at: Optional[datetime] = None

class ItemCreate(BaseModel):
    name: str
    description: Optional[str] = None

# In-memory storage (replace with database later)
items_db = []
next_id = 1

test_opt_problem = create_example_opt_problem()
config = create_test_config()
print(test_opt_problem.get_parameter_info(param_name = 'solvent'))
test_optimizer = create_example_optimizer()
data_df = test_optimizer.get_data_info()
print('data is here ', data_df)

@app.post("/update_config")
async def optimize(request_body: dict):
    config = FastAPIConfigHandler.restore_from_api(request_body["config"])
    problem = config.to_optimization_problem()

    return {"message": "Optimization config updated"}

@app.get("/config")
async def optimization_config():
    return FastAPIConfigHandler.prepare_for_api(config)

@app.get("/optimizer_data")
async def optimizer():
    return data_df.to_dict(orient="records")

#template
@app.get("/")
async def root():
    return {"message": "Welcome to My App API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

@app.get("/items", response_model=List[Item])
async def get_items():
    return items_db

@app.post("/items", response_model=Item)
async def create_item(item: ItemCreate):
    global next_id
    new_item = Item(
        id=next_id,
        name=item.name,
        description=item.description,
        created_at=datetime.now()
    )
    items_db.append(new_item)
    next_id += 1
    return new_item

@app.get("/items/{item_id}", response_model=Item)
async def get_item(item_id: int):
    for item in items_db:
        if item.id == item_id:
            return item
    raise HTTPException(status_code=404, detail="Item not found")

@app.delete("/items/{item_id}")
async def delete_item(item_id: int):
    for i, item in enumerate(items_db):
        if item.id == item_id:
            items_db.pop(i)
            return {"message": "Item deleted successfully"}
    raise HTTPException(status_code=404, detail="Item not found")

# Future authentication endpoints (placeholder)
@app.post("/auth/login")
async def login():
    # TODO: Implement authentication
    return {"message": "Authentication not implemented yet"}

@app.post("/auth/register")
async def register():
    # TODO: Implement user registration
    return {"message": "Registration not implemented yet"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)