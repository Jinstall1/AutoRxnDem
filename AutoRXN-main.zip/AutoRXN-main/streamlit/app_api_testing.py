import streamlit as st
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
# Load required libraries for modeling
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
import seaborn as sns
import requests
import json
from datetime import datetime
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append('/home/kinnunes/WebBO/backend')
from backend.optimization_problem import OptimizationProblem
from backend.test_BO import create_example_opt_problem
from backend.optimization_config import *

API_BASE_URL = "http://localhost:8000"

#FAST API calls
def make_api_request(method, endpoint, data=None):
    """Helper function to make API requests"""
    url = f"{API_BASE_URL}{endpoint}"
    try:
        if method == "GET":
            response = requests.get(url)
        elif method == "POST":
            response = requests.post(url, json=data)
        elif method == "DELETE":
            response = requests.delete(url)
        
        response.raise_for_status()
        return response.json()
    except requests.exceptions.ConnectionError:
        st.error("❌ Cannot connect to API. Make sure FastAPI server is running on http://localhost:8000")
        return None
    except requests.exceptions.HTTPError as e:
        st.error(f"❌ API Error: {e}")
        return None
    

# Set page configuration
def add_logo():
    logo_path = os.path.join(os.path.dirname(__file__), "autorxn_logo.png")
    if os.path.exists(logo_path):
        st.sidebar.image(logo_path, use_column_width=True)
    else:
        st.sidebar.warning("Logo image not found.")

st.set_page_config(
    page_title="Accelerate Chemistry with Intelligence",
    page_icon="🧪",
    layout="wide"
)
add_logo()

# Add a title and some text
st.title("🧪 Accelerate Chemistry with Intelligence")
st.markdown("""

AutoRxn helps chemists optimize reactions with fewer experiments using Bayesian intelligence. No coding required.
""")

# Sidebar with user inputs
st.sidebar.header("Dashboard Settings")
user_name = st.sidebar.text_input("Chemist Name", "Iron Doctor")


# Add a greeting
st.header(f"Welcome, {user_name}! 👋")

# Create tabs for different sections
tab1, tab2, tab3, tab4, tab5 = st.tabs(["Reaction Data", "Yield Analysis", "Add New Reaction", "Suggest Next Experiments", "Predictive Model"])

# Tab 1: Reaction Data Viewer
with tab1:
    st.subheader("Chemical Reaction Database")
    
    # Generate sample data
    data_size = st.slider("Number of reactions to display", 5, 50, 15)
    
    # Create sample reaction data
    np.random.seed(42)  # For reproducibility
    
    # Define possible choices for categorical variables


    # Get current config
    config = make_api_request('GET', '/config')

    # Initialize session state
    StreamlitConfigManager.initialize_session_state()

    # Add a parameter
    new_param = MetaData(parameter_name="pressure", data_type=DataType.continuous)
    StreamlitConfigManager.add_parameter(new_param)

    data = make_api_request('GET', '/optimizer_data')
    df = pd.DataFrame(data)  # Convert back to DataFrame
    solvents =  ["Pd/C", "Pt/Al2O3", "Raney Ni", "CuI", "Fe2O3", "NiCl2"]
    catalysts = ["Pd/C", "Pt/Al2O3", "Raney Ni", "CuI", "Fe2O3", "NiCl2"]
    
    # Create random data for chemical reactions
    data = pd.DataFrame({
        'Reaction_Number': range(1, data_size + 1),
        'Batch_Number': [f"B{np.random.randint(100, 1000)}" for _ in range(data_size)],
        'Pressure_bar': np.random.uniform(1, 10, data_size).round(2),
        'Reagent1_Conc_M': np.random.uniform(0.1, 2.0, data_size).round(2),
        'Reagent2_Conc_M': np.random.uniform(0.1, 1.5, data_size).round(2),
        'Solvent': np.random.choice(solvents, size=data_size),
        'Catalyst': np.random.choice(catalysts, size=data_size),
        'Reaction_Yield_%': np.random.normal(75, 15, data_size).round(1).clip(0, 100)
    })
    
    # Add filter for catalyst type
    selected_catalyst = st.multiselect(
        "Filter by Catalyst",
        options=sorted(data['Catalyst'].unique()),
        default=[]
    )
    
    # Add filter for solvent
    selected_solvent = st.multiselect(
        "Filter by Solvent",
        options=sorted(data['Solvent'].unique()),
        default=[]
    )
    
    # Apply filters if selected
    filtered_data = df.copy()
    if selected_solvent:
        filtered_data = filtered_data[filtered_data['solvent'].isin(selected_solvent)]
    
    # Display the data
    st.data_editor(filtered_data)
    
    # Option to download the data
    st.download_button(
        label="Download reactions as CSV",
        data=filtered_data.to_csv(index=False).encode('utf-8'),
        file_name='chemical_reactions_data.csv',
        mime='text/csv',
    )

# Tab 2: Yield Analysis
with tab2:
    st.subheader("Reaction Yield Analysis")
    
    if 'data' in locals():
        # Select analysis type
        analysis_type = st.selectbox(
            "Select Analysis Type",
            ["Yield by Catalyst", "Yield by Solvent", "Yield vs. Pressure", "Yield vs. Reagent Concentration"]
        )
        
        if analysis_type == "Yield by Catalyst":
            # Calculate average yield by catalyst
            catalyst_data = data.groupby('Catalyst')['Reaction_Yield_%'].mean().sort_values(ascending=False).reset_index()
            
            # Create bar chart
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.bar(catalyst_data['Catalyst'], catalyst_data['Reaction_Yield_%'], color='teal')
            ax.set_title('Average Yield by Catalyst Type')
            ax.set_xlabel('Catalyst')
            ax.set_ylabel('Average Yield (%)')
            ax.set_ylim(0, 100)
            plt.xticks(rotation=45)
            plt.tight_layout()
            st.pyplot(fig)
            
            # Show the data table
            st.write("### Yield Data by Catalyst")
            st.dataframe(catalyst_data)
            
        elif analysis_type == "Yield by Solvent":
            # Calculate average yield by solvent
            solvent_data = data.groupby('Solvent')['Reaction_Yield_%'].mean().sort_values(ascending=False).reset_index()
            
            # Create bar chart
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.bar(solvent_data['Solvent'], solvent_data['Reaction_Yield_%'], color='purple')
            ax.set_title('Average Yield by Solvent Type')
            ax.set_xlabel('Solvent')
            ax.set_ylabel('Average Yield (%)')
            ax.set_ylim(0, 100)
            plt.xticks(rotation=45)
            plt.tight_layout()
            st.pyplot(fig)
            
            # Show the data table
            st.write("### Yield Data by Solvent")
            st.dataframe(solvent_data)
            
        elif analysis_type == "Yield vs. Pressure":
            # Create scatter plot
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.scatter(data['Pressure_bar'], data['Reaction_Yield_%'], alpha=0.7)
            ax.set_title('Reaction Yield vs. Pressure')
            ax.set_xlabel('Pressure (bar)')
            ax.set_ylabel('Yield (%)')
            ax.grid(True, linestyle='--', alpha=0.7)
            
            # Add regression line
            z = np.polyfit(data['Pressure_bar'], data['Reaction_Yield_%'], 1)
            p = np.poly1d(z)
            ax.plot(data['Pressure_bar'], p(data['Pressure_bar']), "r--", alpha=0.8)
            
            st.pyplot(fig)
            
            # Show correlation
            correlation = data['Pressure_bar'].corr(data['Reaction_Yield_%']).round(3)
            st.write(f"### Correlation between Pressure and Yield: {correlation}")
            
        else:  # Yield vs. Reagent Concentration
            # Select which reagent to analyze
            reagent_choice = st.radio(
                "Select Reagent:",
                ["Reagent 1", "Reagent 2"]
            )
            
            column_name = 'Reagent1_Conc_M' if reagent_choice == "Reagent 1" else 'Reagent2_Conc_M'
            
            # Create scatter plot
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.scatter(data[column_name], data['Reaction_Yield_%'], alpha=0.7)
            ax.set_title(f'Reaction Yield vs. {reagent_choice} Concentration')
            ax.set_xlabel(f'{reagent_choice} Concentration (M)')
            ax.set_ylabel('Yield (%)')
            ax.grid(True, linestyle='--', alpha=0.7)
            
            # Add regression line
            z = np.polyfit(data[column_name], data['Reaction_Yield_%'], 1)
            p = np.poly1d(z)
            ax.plot(data[column_name], p(data[column_name]), "r--", alpha=0.8)
            
            st.pyplot(fig)
            
            # Show correlation
            correlation = data[column_name].corr(data['Reaction_Yield_%']).round(3)
            st.write(f"### Correlation between {reagent_choice} Concentration and Yield: {correlation}")
    else:
        st.write("No data available for analysis. Please generate data in the Reaction Data tab.")

# Tab 3: Add New Reaction
with tab3:
    st.subheader("Add New Reaction Data")
    
    # Create columns for form layout
    col1, col2 = st.columns(2)
    
    with col1:
        new_batch = st.text_input("Batch Number", value="B" + str(np.random.randint(100, 1000)))
        new_pressure = st.slider("Pressure (bar)", 1.0, 10.0, 5.0, 0.1)
        new_reagent1 = st.slider("Reagent 1 Concentration (M)", 0.1, 2.0, 1.0, 0.1)
        new_reagent2 = st.slider("Reagent 2 Concentration (M)", 0.1, 1.5, 0.5, 0.1)
    
    with col2:
        new_solvent = st.selectbox("Solvent", options=["Toluene", "Methanol", "THF", "Acetone", "DMF", "Water"])
        new_catalyst = st.selectbox("Catalyst", options=["Pd/C", "Pt/Al2O3", "Raney Ni", "CuI", "Fe2O3", "NiCl2"])
        new_yield = st.slider("Reaction Yield (%)", 0.0, 100.0, 75.0, 0.1)
    
    # Add reaction button
    if st.button("Add Reaction"):
        # Check if data exists
        if 'data' in locals():
            # Create new reaction data
            new_reaction = pd.DataFrame({
                'Reaction_Number': [data['Reaction_Number'].max() + 1],
                'Batch_Number': [new_batch],
                'Pressure_bar': [new_pressure],
                'Reagent1_Conc_M': [new_reagent1],
                'Reagent2_Conc_M': [new_reagent2],
                'Solvent': [new_solvent],
                'Catalyst': [new_catalyst],
                'Reaction_Yield_%': [new_yield]
            })
            
            # Add the new reaction to the existing data
            data = pd.concat([data, new_reaction], ignore_index=True)
            
            st.success(f"Reaction {new_batch} added successfully!")
            st.dataframe(new_reaction)
        else:
            st.error("Please generate data in the Reaction Data tab first.")
    
    # Note about data persistence
    st.info("Note: Added reactions will remain in the dataset only for this session. Data will be lost when you refresh the page, as this is a simple demo without a backend database.")

# Tab 4: Suggest Next Experiments
with tab4:
    st.subheader("Suggest Next Experiments")
    
    st.markdown("""
    This tool will suggest new experiments based on your current data, focusing on promising conditions 
    while exploring new parameter combinations.
    """)
    
    # Batch size selection
    num_suggestions = st.slider("Number of Experiments to Suggest", 1, 10, 3)
    
    # Add options for experiment focus
    experiment_focus = st.radio(
        "Experiment Focus",
        ["Optimize Yield", "Explore Parameter Space", "Test New Catalysts"]
    )
    
    # Generate suggestions button
    if st.button("Generate Experiment Suggestions"):
        if 'data' in locals():
            # Seed for reproducibility but with some variation each time
            np.random.seed(int(pd.Timestamp.now().timestamp()) % 1000)
            
            # Get unique values from existing data
            solvents = list(data['Solvent'].unique())
            catalysts = list(data['Catalyst'].unique())
            
            # Add some new options to expand exploration
            all_solvents = list(set(solvents + ["DMSO", "Ethanol", "Acetonitrile", "Chloroform"]))
            all_catalysts = list(set(catalysts + ["ZnCl2", "TiO2", "RuCl3", "DMAP"]))
            
            suggested_experiments = []
            
            # Logic for experiment suggestions based on focus
            if experiment_focus == "Optimize Yield":
                # Find best performing conditions
                best_catalyst = data.groupby('Catalyst')['Reaction_Yield_%'].mean().sort_values(ascending=False).index[0]
                best_solvent = data.groupby('Solvent')['Reaction_Yield_%'].mean().sort_values(ascending=False).index[0]
                
                # Create variations around the best conditions
                for i in range(num_suggestions):
                    exp = {
                        'Reaction_Number': f"S{i+1}",  # S for Suggested
                        'Batch_Number': f"B{np.random.randint(1000, 9999)}",
                        'Pressure_bar': round(min(10, max(1, np.random.normal(
                            data[data['Catalyst'] == best_catalyst]['Pressure_bar'].mean(), 0.5))), 2),
                        'Reagent1_Conc_M': round(min(2, max(0.1, np.random.normal(
                            data[data['Catalyst'] == best_catalyst]['Reagent1_Conc_M'].mean(), 0.2))), 2),
                        'Reagent2_Conc_M': round(min(1.5, max(0.1, np.random.normal(
                            data[data['Catalyst'] == best_catalyst]['Reagent2_Conc_M'].mean(), 0.15))), 2),
                        'Solvent': best_solvent,
                        'Catalyst': best_catalyst,
                        'Reaction_Yield_%': None  # Empty for user to fill in
                    }
                    suggested_experiments.append(exp)
                
            elif experiment_focus == "Explore Parameter Space":
                # Create experiments with wide parameter ranges
                for i in range(num_suggestions):
                    exp = {
                        'Reaction_Number': f"S{i+1}",
                        'Batch_Number': f"B{np.random.randint(1000, 9999)}",
                        'Pressure_bar': round(np.random.uniform(1, 10), 2),
                        'Reagent1_Conc_M': round(np.random.uniform(0.1, 2.0), 2),
                        'Reagent2_Conc_M': round(np.random.uniform(0.1, 1.5), 2),
                        'Solvent': np.random.choice(all_solvents),
                        'Catalyst': np.random.choice(all_catalysts),
                        'Reaction_Yield_%': None
                    }
                    suggested_experiments.append(exp)
                    
            else:  # Test New Catalysts
                # Focus on new catalysts with consistent other parameters
                avg_pressure = data['Pressure_bar'].mean()
                avg_reagent1 = data['Reagent1_Conc_M'].mean()
                avg_reagent2 = data['Reagent2_Conc_M'].mean()
                best_solvent = data.groupby('Solvent')['Reaction_Yield_%'].mean().sort_values(ascending=False).index[0]
                
                # Get catalysts not in the original dataset or less frequently used
                new_catalysts = [cat for cat in all_catalysts if cat not in catalysts]
                if len(new_catalysts) < num_suggestions:
                    new_catalysts = all_catalysts
                
                for i in range(num_suggestions):
                    exp = {
                        'Reaction_Number': f"S{i+1}",
                        'Batch_Number': f"B{np.random.randint(1000, 9999)}",
                        'Pressure_bar': round(avg_pressure * np.random.uniform(0.9, 1.1), 2),
                        'Reagent1_Conc_M': round(avg_reagent1 * np.random.uniform(0.9, 1.1), 2),
                        'Reagent2_Conc_M': round(avg_reagent2 * np.random.uniform(0.9, 1.1), 2),
                        'Solvent': best_solvent,
                        'Catalyst': np.random.choice(new_catalysts),
                        'Reaction_Yield_%': None
                    }
                    suggested_experiments.append(exp)
            
            # Convert to DataFrame
            suggested_df = pd.DataFrame(suggested_experiments)
            
            # Display the suggested experiments
            st.success(f"Generated {num_suggestions} experiment suggestions!")
            st.dataframe(suggested_df)
            
            # Create an editable version for the user
            st.write("### Enter Your Results")
            st.write("Add your results after running these experiments:")
            
            # Editable DataFrame doesn't exist in Streamlit, so we'll use a workaround with form inputs
            for i, exp in enumerate(suggested_experiments):
                with st.expander(f"Experiment {i+1}: Batch {exp['Batch_Number']}"):
                    st.write(f"**Reaction conditions:**")
                    st.write(f"- Pressure: {exp['Pressure_bar']} bar")
                    st.write(f"- Reagent 1: {exp['Reagent1_Conc_M']} M")
                    st.write(f"- Reagent 2: {exp['Reagent2_Conc_M']} M")
                    st.write(f"- Solvent: {exp['Solvent']}")
                    st.write(f"- Catalyst: {exp['Catalyst']}")
                    
                    # Input for the yield
                    key = f"yield_{i}"
                    yield_value = st.number_input("Enter Yield (%)", 
                                                 min_value=0.0, 
                                                 max_value=100.0, 
                                                 value=None, 
                                                 step=0.1,
                                                 key=key)
                    
                    # Button to add this result to the main dataset
                    if st.button(f"Add Result to Dataset", key=f"add_{i}"):
                        if yield_value is not None:
                            # Create a new row
                            new_reaction = pd.DataFrame({
                                'Reaction_Number': [data['Reaction_Number'].max() + 1 if len(data) > 0 else 1],
                                'Batch_Number': [exp['Batch_Number']],
                                'Pressure_bar': [exp['Pressure_bar']],
                                'Reagent1_Conc_M': [exp['Reagent1_Conc_M']],
                                'Reagent2_Conc_M': [exp['Reagent2_Conc_M']],
                                'Solvent': [exp['Solvent']],
                                'Catalyst': [exp['Catalyst']],
                                'Reaction_Yield_%': [yield_value]
                            })
                            
                            # Add to the dataset
                            data = pd.concat([data, new_reaction], ignore_index=True)
                            st.success(f"Added experiment {exp['Batch_Number']} with yield {yield_value}% to the dataset!")
                        else:
                            st.warning("Please enter a yield value before adding to the dataset.")
            
            # Download button for experiment plan
            csv = suggested_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                "Download Experiment Plan as CSV",
                csv,
                "suggested_experiments.csv",
                "text/csv",
                key='download-suggested-csv'
            )
        else:
            st.error("Please generate data in the Reaction Data tab first.")

# Tab 5: Predictive Model
with tab5:
    st.subheader("Predictive Model: Marginal Effects")
    
    if 'data' in locals() and len(data) > 5:  # Need some minimum amount of data
        st.write("""
        ### Reaction Yield Predictor
        
        This model shows how each variable affects the reaction yield when other variables are held constant. 
        The shaded area represents the 95% confidence interval.
        """)
        
        # Create a copy of data for modeling to avoid modifying the original
        model_data = data.copy()
        
        # Drop rows with NaN values in the target or key features
        model_data = model_data.dropna(subset=['Reaction_Yield_%'])
        
        # Fit a simple model for demonstration
        # In a real app, you'd use more sophisticated methods like cross-validation
        
        # Define features
        numeric_features = ['Pressure_bar', 'Reagent1_Conc_M', 'Reagent2_Conc_M']
        categorical_features = ['Solvent', 'Catalyst']
        
        # Create preprocessing pipeline with imputers for handling missing values
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', Pipeline([
                    ('imputer', SimpleImputer(strategy='mean')),
                    ('passthrough', 'passthrough')
                ]), numeric_features),
                ('cat', Pipeline([
                    ('imputer', SimpleImputer(strategy='most_frequent')),
                    ('onehot', OneHotEncoder(handle_unknown='ignore'))
                ]), categorical_features)
            ])
        
        # Create and fit the model pipeline
        model = Pipeline(steps=[
            ('preprocessor', preprocessor),
            ('regressor', LinearRegression())
        ])
        
        # Try to fit the model and handle potential errors
        try:
            # Make sure we have enough data with non-null values
            if len(model_data) < 5:
                raise ValueError("Not enough data points after removing rows with missing values")
                
            # Check if we have at least some variation in each feature
            for feature in numeric_features + categorical_features:
                if model_data[feature].nunique() < 2:
                    raise ValueError(f"Feature '{feature}' has only one unique value")
            
            X = model_data[numeric_features + categorical_features]
            y = model_data['Reaction_Yield_%']
            
            # Check for any remaining NaN values and warn about them
            if X.isnull().any().any() or y.isnull().any():
                st.warning("Some data points contain missing values. They will be imputed using mean/mode values.")
            
            model.fit(X, y)
            
            # Select variable to visualize
            variable_to_plot = st.selectbox(
                "Select Variable to Visualize Effect",
                ['Pressure_bar', 'Reagent1_Conc_M', 'Reagent2_Conc_M', 'Solvent', 'Catalyst']
            )
            
            # Plot marginal effects for the selected variable
            if variable_to_plot in numeric_features:
                # For numeric variables, create a range of values
                min_val = float(model_data[variable_to_plot].min())
                max_val = float(model_data[variable_to_plot].max())
                
                # Create range with some padding
                padding = (max_val - min_val) * 0.2
                x_range = np.linspace(max(0, min_val - padding), max_val + padding, 100)
                
            # Create test points by holding other variables at their means/modes
                test_data = pd.DataFrame()
                
                # Set numeric features to their means
                for feat in numeric_features:
                    if feat == variable_to_plot:
                        test_data[feat] = x_range
                    else:
                        test_data[feat] = model_data[feat].mean()
                
                # Set categorical features to their modes
                for feat in categorical_features:
                    mode_value = model_data[feat].mode()[0]
                    test_data[feat] = mode_value
                
                # Make predictions - handle any remaining NaN values
                # Predictions will use the imputation from the pipeline
                y_pred = model.predict(test_data[numeric_features + categorical_features])
                
                # Calculate confidence intervals (fake but realistic for visualization)
                # Using standard error formula: se = sigma / sqrt(n)
                n = len(model_data)
                sigma = np.std(model_data['Reaction_Yield_%'])
                se = sigma / np.sqrt(n)
                
                # 95% CI is roughly +/- 2*se
                confidence = 1.96 * se
                
                # Add some noise to make the CI look realistic
                # Wider at the edges, narrower in data-dense regions
                distance_from_center = np.abs(x_range - np.mean(x_range))
                max_distance = np.max(distance_from_center)
                ci_width = confidence * (1 + 0.5 * distance_from_center / max_distance)
                
                # Plot the marginal effect
                fig, ax = plt.subplots(figsize=(10, 6))
                
                # Plot the confidence interval
                ax.fill_between(x_range, 
                               y_pred - ci_width, 
                               y_pred + ci_width, 
                               alpha=0.3, 
                               color='blue', 
                               label='95% Confidence Interval')
                
                # Plot the prediction line
                ax.plot(x_range, y_pred, color='blue', label='Predicted Yield')
                
                # Plot the actual data points
                ax.scatter(model_data[variable_to_plot], model_data['Reaction_Yield_%'], 
                          alpha=0.6, color='red', label='Actual Data')
                
                # Add labels and title
                ax.set_xlabel(variable_to_plot)
                ax.set_ylabel('Predicted Yield (%)')
                ax.set_title(f'Marginal Effect of {variable_to_plot} on Reaction Yield')
                ax.grid(True, linestyle='--', alpha=0.7)
                ax.legend()
                
                st.pyplot(fig)
                
                # Calculate and display the estimated effect
                effect_size = y_pred.max() - y_pred.min()
                st.write(f"**Estimated Effect Size:** A change in {variable_to_plot} from {x_range.min():.2f} to {x_range.max():.2f} "
                        f"is associated with a {abs(effect_size):.2f}% {'increase' if effect_size > 0 else 'decrease'} in yield.")
                
            else:  # For categorical variables
                # Get unique values
                unique_values = sorted(model_data[variable_to_plot].unique())
                
                # Create test data, one for each category value
                all_preds = []
                category_names = []
                
                for value in unique_values:
                    test_data = pd.DataFrame()
                    
                    # Set numeric features to their means
                    for feat in numeric_features:
                        test_data[feat] = [model_data[feat].mean()]
                    
                    # Set categorical features to their modes, except the one we're varying
                    for feat in categorical_features:
                        if feat == variable_to_plot:
                            test_data[feat] = [value]
                        else:
                            test_data[feat] = [model_data[feat].mode()[0]]
                    
                    # Make prediction
                    pred = model.predict(test_data[numeric_features + categorical_features])[0]
                    all_preds.append(pred)
                    category_names.append(value)
                
                # Calculate confidence intervals (fake but realistic)
                n = len(model_data)
                sigma = np.std(model_data['Reaction_Yield_%'])
                se = sigma / np.sqrt(n)
                confidence = 1.96 * se
                
                # Vary CI width based on category frequency
                ci_widths = []
                for cat in category_names:
                    # Less frequent categories have wider CIs
                    cat_freq = sum(model_data[variable_to_plot] == cat) / n
                    ci_widths.append(confidence * (1 + 0.5 * (1 - cat_freq)))
                
                # Create a bar plot
                fig, ax = plt.subplots(figsize=(10, 6))
                
                # Plot bars
                bars = ax.bar(category_names, all_preds, color='blue', alpha=0.7)
                
                # Add error bars
                ax.errorbar(category_names, all_preds, yerr=ci_widths, fmt='none', color='black', capsize=5)
                
                # Add labels and title
                ax.set_xlabel(variable_to_plot)
                ax.set_ylabel('Predicted Yield (%)')
                ax.set_title(f'Effect of {variable_to_plot} on Reaction Yield')
                ax.grid(True, linestyle='--', alpha=0.7, axis='y')
                
                # Rotate x labels if there are many categories
                if len(category_names) > 3:
                    plt.xticks(rotation=45)
                
                st.pyplot(fig)
                
                # Find best and worst categories
                best_cat = category_names[np.argmax(all_preds)]
                worst_cat = category_names[np.argmin(all_preds)]
                diff = max(all_preds) - min(all_preds)
                
                st.write(f"**Estimated Effect:** Changing {variable_to_plot} from {worst_cat} to {best_cat} "
                        f"is associated with a {diff:.2f}% increase in yield.")
            
            # Add model quality metrics
            st.write("### Model Diagnostics")
            
            # Check model fit - use only non-NaN values
            y_pred_train = model.predict(X)
            r2 = np.corrcoef(y, y_pred_train)[0, 1]**2  # Calculate R² from correlation
            
            # Create metrics display
            col1, col2 = st.columns(2)
            col1.metric("R² (Model Fit)", f"{r2:.2f}")
            col2.metric("Data Points", f"{len(model_data)}")
            
            # Add a disclaimer
            st.info("""
            ⚠️ **Note:** This is a simplified predictive model for demonstration purposes. 
            In a production environment, you would use more sophisticated modeling techniques 
            like cross-validation, regularization, and potentially more complex models.
            """)
            
        except Exception as e:
            st.error(f"""
            Could not build the predictive model. Possible reasons:
            - Not enough data points (need at least 5)
            - Not enough variation in the data
            - Some features have only one unique value
            
            Try adding more varied data points with different conditions and yields.
            
            Technical error: {str(e)}
            """)
            
            # Add more detailed debugging information
            if 'X' in locals() and 'y' in locals():
                st.expander("Debugging Information (for developers)").write(f"""
                - Data shape: {X.shape}
                - Missing values in features: {X.isnull().sum().to_dict()}
                - Missing values in target: {sum(y.isnull())}
                - Unique values per feature: {X.nunique().to_dict()}
                """)
    else:
        st.warning("You need at least 6 data points to build a predictive model. Please add more reaction data.")
        
        # Show a preview of what the model will look like
        st.write("### Preview: Marginal Effects Visualization")
        
        # Create sample preview image
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Fake data for preview
        x = np.linspace(0, 10, 100)
        y = 65 + 2 * x - 0.15 * x**2 + np.random.normal(0, 2, 100)
        
        # Plot the confidence interval
        ax.fill_between(x, y - 5, y + 5, alpha=0.3, color='blue', label='95% Confidence Interval')
        
        # Plot the prediction line
        ax.plot(x, 65 + 2 * x - 0.15 * x**2, color='blue', label='Predicted Yield')
        
        # Plot some fake data points
        ax.scatter(x[::10], y[::10], alpha=0.6, color='red', label='Example Data')
        
        ax.set_xlabel('Pressure (bar)')
        ax.set_ylabel('Predicted Yield (%)')
        ax.set_title('Preview: Marginal Effect of Pressure on Reaction Yield')
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.legend()
        
        st.pyplot(fig)

# Footer
st.divider()
st.caption("Chemical Reactions Dashboard • " + pd.Timestamp.now().strftime("%Y-%m-%d"))