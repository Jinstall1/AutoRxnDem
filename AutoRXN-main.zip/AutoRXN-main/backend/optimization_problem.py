"""
Optimization Problem Module

This module contains the OptimizationProblem class for defining and managing
optimization problems with mixed variable types (continuous, categorical, ordinal).
"""

from typing import List, Optional, Any, Callable, Dict
import torch
import numpy as np
from pydantic import BaseModel, Field, field_validator, computed_field
from enum import Enum
from metadata import MetaData
from metadata import DataType
# Make sure to import your MetaData class
# from your_module import MetaData

class OptimizationProblem(BaseModel):
    """
    A Pydantic class to represent an optimization problem with support for mixed variable types.

    This class manages optimization problems that can contain continuous,
    categorical, and ordinal variables. It provides functionality to count
    different variable types and evaluate solutions.
    """
    
    # Core problem definition - CHANGED FROM List[Any] to List[MetaData]
    param_metadatas: List[MetaData] = Field(..., description="List of MetaData objects defining the problem variables")
    targets: List[MetaData] = Field(..., description="List of MetaData objects defining the optimization targets")
    # Optimization settings
    maximize: bool = Field(default=True, description="Whether to maximize (True) or minimize (False) the objective")
    n_outputs: int = Field(default=1, description="Number of output variables")
    evaluation_f: Optional[Callable] = Field(default=None, description="Function to evaluate solutions", exclude=True)
    
    # Computed properties
    @computed_field
    @property
    def n_cat_choices(self) -> List[int]:
        """Collect number of categorical choices for each variable into a single list
        
        Returns:
            List[int]: number of categorical choices per categorical and ordinal variables
        """
        n_cat_choices = []
        for metadata in self.param_metadatas:
            # Now you can access metadata.data_type directly since it's a MetaData object
            if metadata.data_type == DataType.categorical:  # Use enum comparison
                n_cat_choices.append(metadata.n_cat_choices)
        return n_cat_choices
    
    @computed_field
    @property
    def n_con(self) -> int:
        """
        Calculate the number of continuous variables in the problem.
        
        Returns:
            int: Number of continuous variables
        """
        if not self.param_metadatas:
            return 0
        
        n_con = 0
        for metadata in self.param_metadatas:
            # Direct access, no need for hasattr
            if metadata.data_type == DataType.continuous:  # Use enum comparison
                n_con += 1
        return n_con
    
    @computed_field
    @property
    def n_cat(self) -> int:
        """
        Calculate the number of categorical variables in the problem.
        
        Returns:
            int: Number of categorical variables
        """
        if not self.param_metadatas:
            return 0
        
        n_cat = 0
        for metadata in self.param_metadatas:
            if metadata.data_type == DataType.categorical:  # Use enum comparison
                n_cat += 1
        return n_cat
    
    @computed_field
    @property
    def n_ord(self) -> int:
        """
        Calculate the number of ordinal variables in the problem.
        
        Returns:
            int: Number of ordinal variables
        """
        if not self.param_metadatas:
            return 0
        
        n_ord = 0
        for metadata in self.param_metadatas:
            if metadata.data_type == DataType.ordinal:  # Use enum comparison
                n_ord += 1
        return n_ord
    
    
    @field_validator('n_outputs')
    @classmethod
    def validate_n_outputs(cls, v):
        """Validate number of outputs is positive"""
        if v < 1:
            raise ValueError("n_outputs must be at least 1")
        return v
    
    # Pydantic configuration
    model_config = {
        "arbitrary_types_allowed": True,  # Allow torch.Tensor and custom types
        "validate_assignment": True,      # Validate on assignment
    }
    
    def set_evaluation_function(self, func: Callable) -> None:
        """
        Set the evaluation function for the optimization problem.
        
        Args:
            func: Callable function that takes a tensor and returns evaluation result
        """
        self.evaluation_f = func
    
    def evaluate(self, X: torch.Tensor) -> torch.Tensor:
        """
        Evaluate a solution vector using the defined evaluation function.
        
        Takes a solution vector and applies the evaluation function to compute
        the objective value. Handles both maximization and minimization problems.
        
        Args:
            X: input as a torch tensor [shape n_inputs x n_parameters]
        
        Returns:
            torch.Tensor: output as a torch tensor [shape n_inputs x n_outputs]
            
        Raises:
            ValueError: If evaluation_f is not set or Y has incorrect dimensions
            TypeError: If X is not a valid torch tensor
        """
        # Input validation
        if self.evaluation_f is None:
            raise ValueError("Evaluation function (evaluation_f) must be set before evaluation")
        
        if not isinstance(X, torch.Tensor):
            raise TypeError("Input X must be a torch tensor")
        
        # Evaluate using the provided function
        try:  
            Y = []
            for i in range(X.shape[0]):
                result = self.evaluation_f(X[i, :])
                if not isinstance(result, torch.Tensor):
                    result = torch.tensor(result)
                Y.append(result.view(1, -1))
            Y = torch.concat(Y, dim=0)
            
        except Exception as e:
            raise RuntimeError(f"Error during evaluation: {str(e)}")

        # Convert to maximization if needed
        if not self.maximize:
            Y = -Y
            
        return Y.double()
    
    def get_parameter_info(self, param_name):
        for param in self.param_metadatas:
            if param.parameter_name == param_name:
                return param

    def get_problem_info(self) -> Dict[str, Any]:
        """
        Get comprehensive information about the optimization problem.
        
        Returns:
            Dict[str, Any]: Dictionary containing problem specifications including
                variable counts, optimization direction, and setup status
        """
        return {
            'total_variables': self.n_con + self.n_cat + self.n_ord,
            'continuous_variables': self.n_con,
            'categorical_variables': self.n_cat,
            'ordinal_variables': self.n_ord,
            'maximize': self.maximize,
            'evaluation_function_set': self.evaluation_f is not None,
            'metadatas_configured': len(self.param_metadatas) > 0
        }
    
    def __str__(self) -> str:
        """
        String representation of the optimization problem.
        
        Returns:
            str: Human-readable description of the problem
        """
        direction = "maximization" if self.maximize else "minimization"
        total_vars = self.n_con + self.n_cat + self.n_ord
        
        return (f"OptimizationProblem({direction}, {total_vars} variables: "
                f"{self.n_con} continuous, {self.n_cat} categorical, "
                f"{self.n_ord} ordinal)")