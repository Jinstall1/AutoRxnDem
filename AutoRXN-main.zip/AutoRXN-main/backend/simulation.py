import torch

class Simulation:
    def __init__(self, optimizer):
        self.optimizer = optimizer
    
    def run_BO(self, n_iterations, batch_size):
        for i in range(n_iterations):
            self.optimizer.update_surrogate()
            candidates = self.optimizer.generate_candidates(batch_size)
            Y = self.optimizer.opt_problem.evaluate(candidates)
            self.optimizer.train_X = torch.cat([self.optimizer.train_X, candidates])
            self.optimizer.train_Y = torch.cat([self.optimizer.train_Y, Y])
            print(f'{i+1}: current max = {self.optimizer.train_Y.max()}')


        