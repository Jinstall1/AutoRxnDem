import torch
def beam_bending(x):
    # Calculate length and height
    t = x[0] +1
    L = 10 + 10 * x[1]
    h = 1 + x[2]
    
    # Initialize moment of inertia array
    I = torch.clone(t)
    
    # Set moment of inertia values based on type
    I[t == 1] = torch.pi / 64          # 0.0491
    I[t == 2] = 1 / 12              # 0.0833
    I[t == 3] = 0.0449
    I[t == 4] = (1 - 0.7**4) / 12   # 0.063
    I[t == 5] = torch.pi / 64 * (1 - 0.7**4)  # 0.0373
    I[t == 6] = 0.1**3 * 0.8 / 12 + 1 / 12 * 0.2  # 0.0167
    
    # Calculate final result
    y = 0.333e-9 * L**3 / (I * h**4)
    
    return y
