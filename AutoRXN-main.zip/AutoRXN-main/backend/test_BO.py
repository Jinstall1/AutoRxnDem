from bayesian_optimizer import BayesianOptimizer
from optimization_problem import OptimizationProblem
from metadata import MetaData
from simulation import Simulation
from utils import *
from test_functions import *
import torch
from metadata import DataType
from optimization_config import *

def create_example_opt_problem():
    Param1 = MetaData(
        parameter_name='solvent',
        data_type=DataType.categorical,  # Use enum value, not string
        n_cat_choices=6, 
        choices=["Toluene", "Methanol", "THF", "Acetone", "DMF", "Water"]
    )
    MetaData.model_validate(Param1)
    
    Param2 = MetaData(
        data_type=DataType.continuous,  # Use enum value, not string
        parameter_name = 'pressure',
    )
    Param3 = MetaData(
        data_type=DataType.continuous,  # Use enum value, not string
        parameter_name = 'temperature',
    )

    target = MetaData(data_type=DataType.target, parameter_name='yield')
    param_metadatas = [Param1, Param2, Param3]
    return OptimizationProblem(param_metadatas=param_metadatas, targets=[target])

def create_example_optimizer():
    opt_problem = create_example_opt_problem()
    OptimizationProblem.model_validate(opt_problem)
    opt_problem.evaluation_f = beam_bending

    #Create initial data
    train_X = torch.tensor(
        [[2, 0.1, 0.9],
        [1, 0.4, 0.5],
        [5, 0.2, 0.3],]
    )
    train_Y = opt_problem.evaluate(train_X)

    optimizer = BayesianOptimizer(opt_problem=opt_problem,
                                AF_type='EI',
                                surrogate_type='GP',
                                train_X=train_X,
                                train_Y=train_Y
                                )
    return optimizer

def run_BO():
    opt_problem = create_example_opt_problem()
    OptimizationProblem.model_validate(opt_problem)
    opt_problem.evaluation_f = beam_bending

    #Create initial data
    train_X = torch.tensor(
        [[2, 0.1, 0.9],
        [1, 0.4, 0.5],
        [5, 0.2, 0.3],]
    )
    train_Y = opt_problem.evaluate(train_X).view(-1,1)

    optimizer = BayesianOptimizer(opt_problem=opt_problem,
                                AF_type='EI',
                                surrogate_type='GP',
                                train_X=train_X,
                                train_Y=train_Y
                                )
    df = optimizer.get_data_info()
    simulation = Simulation(optimizer=optimizer)
    simulation.run_BO(n_iterations=10,
                    batch_size=5)
    

# Example usage and testing
def create_test_config():
    # Create sample configuration
    sample_params = [
        MetaData(
            parameter_name="temperature",
            unit="°C",
            data_type=DataType.continuous,
            search_space=(20.0, 80.0)
    ),
        MetaData(
        data_type=DataType.continuous,  # Use enum value, not string
        parameter_name = 'temperature',
        search_space=(20.0, 80.0)
    ),
        MetaData(
            parameter_name="solvent",
            unit="",
            data_type=DataType.categorical,
            choices=["Toluene", "Methanol", "THF", "Acetone", "DMF", "Water"],
            n_cat_choices=6
        ),

    ]
    
    sample_targets = [
        MetaData(
            parameter_name="Yield",
            unit="%",
            data_type=DataType.target,
            search_space=(0.0, 100.0)
        )
    ]
    
    config = OptimizationConfig(
        problem_name="Material Selection",
        description="Optimize material and temperature for maximum efficiency",
        parameters=sample_params,
        targets=sample_targets,
        maximize=True
    )
    return config
if __name__ == "__main__":
    create_test_config()