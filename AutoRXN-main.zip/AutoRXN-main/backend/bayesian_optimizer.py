from botorch.acquisition import qLogExpectedImprovement
from botorch.models import MixedSingleTaskGP
from botorch.models.transforms import Normalize, Standardize
from botorch.fit import fit_gpytorch_mll
from botorch.optim import optimize_acqf_mixed
from gpytorch.mlls import ExactMarginalLogLikelihood
import torch
import pandas as pd

class BayesianOptimizer:
    def __init__(self, opt_problem:object, AF_type:str, surrogate_type:str, train_X: torch.tensor, train_Y: torch.tensor):
        self.opt_problem = opt_problem
        self.surrogate_type = surrogate_type
        self.mll = None
        self.train_X = train_X.double()
        self.train_Y = train_Y.double()
        self.surrogate = self.init_surrogate()
        self.AF = self.init_AF(AF_type)

    def init_surrogate(self):
        if self.surrogate_type == 'GP' and self.opt_problem.n_outputs == 1:
            cat_dims = torch.arange(0,self.opt_problem.n_cat)
            surrogate = MixedSingleTaskGP(train_X=self.train_X, train_Y=self.train_Y, cat_dims = cat_dims)
            self.mll = ExactMarginalLogLikelihood(surrogate.likelihood, surrogate)
        return surrogate

    def update_surrogate(self):
        self.init_surrogate()
        fit_gpytorch_mll(self.mll)

    def generate_candidates(self, n_points):
        con_bounds = []
        cat_bounds = []
        for i in range(self.opt_problem.n_con):
            con_bounds.append(torch.tensor([0.,1.]).view(2,1))

        for n_choices in self.opt_problem.n_cat_choices:
            cat_bounds.append(torch.tensor([0, n_choices-1]))

        fixed_features_list = [{}]
        cat_bounds = torch.hstack(cat_bounds).view(2,-1)
        con_bounds = torch.hstack(con_bounds).view(2,-1)
        bounds = torch.hstack([cat_bounds, con_bounds])
        candidates, afv = optimize_acqf_mixed(self.AF, 
                                             q = n_points, 
                                             fixed_features_list = fixed_features_list,
                                             bounds = bounds, 
                                             num_restarts=5,
                                             raw_samples=24) #number of raw samples might be a bit low now to keep computational load minimum
        return candidates
    
    def get_data_info(self):
        train_X = self.train_X.numpy()
        train_Y = self.train_Y.numpy()
        df_dict = {}
        for i, param in enumerate(self.opt_problem.param_metadatas):
            df_dict[param.parameter_name] = train_X[:,i]

        for j, target in enumerate(self.opt_problem.targets):
            df_dict[target.parameter_name] = train_Y[:,j]

        df = pd.DataFrame.from_dict(df_dict)
        return df
    

    def init_AF(self, AF_type):
        if self.opt_problem.maximize:
            best_f = torch.max(self.train_Y)
        else:
            best_f = torch.min(self.train_Y)

        if AF_type == 'EI':
            AF = qLogExpectedImprovement(model=self.surrogate,best_f=best_f)
        return AF
            
    
