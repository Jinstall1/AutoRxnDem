## Moneytization
- Freemium model where some features are only available with extra fee / or paid subscription
### List of potential freemium features:
- Multi-objective optimization
- Optimization with larger search space e.g. more than 10 parameters
- Exotic acquisition function (AF) such as Maximum-entropy search
- Larger batces
- Non-myopic BO - BO that considers multiple steps ahead

## Features for the 1st MVP - DL 30.6.2025
- Filtering and editing of current data
- Basic BO with Expected Improvement AF with a single objective, standard GP as surrogate model
- Visualization of the response surface
## Features to be added later:
- Support for ordinal variables

## Terminology:
### Project hierarchy
- Each **user** has a set of 'projects'
- each **project** consists of set of **batch**(es)
- Each batch includes at least 1 **experiment**
### Optimization appreviations
- Bayesian optimization = BO
- Acquisition function = AF
  - Expected Improvement = EI
  - Upper condifence bound = UCB
- Gaussian processes = GP

